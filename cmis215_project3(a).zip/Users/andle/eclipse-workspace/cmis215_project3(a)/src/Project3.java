import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project3 extends JFrame {
    private JTextField distanceField, gasolineCostField, gasMileageField, hotelCostField, foodCostField, daysField, attractionsCostField;
    private JComboBox<String> distanceUnits, gasolineCostUnits, gasMileageUnits;
    private JLabel totalCostLabel;
    
    public Project3() {
        createGUI();
    }
    
    private void createGUI() {
        setTitle("Road Trip Cost Estimator");
        setLayout(new BorderLayout()); // Change to BorderLayout for overall frame layout

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS)); // Vertical BoxLayout for input fields

        // Initialize the text fields with default values
        distanceField = new JTextField("0", 10);
        gasolineCostField = new JTextField("0", 10);
        gasMileageField = new JTextField("0", 10);
        hotelCostField = new JTextField("0", 10);
        foodCostField = new JTextField("0", 10);
        daysField = new JTextField("0", 10);
        attractionsCostField = new JTextField("0", 10);

        // Initialize the combo boxes
        distanceUnits = new JComboBox<>(new String[]{"Miles", "Kilometers"});
        gasolineCostUnits = new JComboBox<>(new String[]{"Dollars per Gallon", "Dollars per Liter"});
        gasMileageUnits = new JComboBox<>(new String[]{"Miles per Gallon", "Kilometers per Liter"});

        // Add components to inputPanel using a method that ensures proper alignment
        inputPanel.add(createInputRow("Distance:", distanceField, distanceUnits));
        inputPanel.add(createInputRow("Gasoline Cost:", gasolineCostField, gasolineCostUnits));
        inputPanel.add(createInputRow("Gas Mileage:", gasMileageField, gasMileageUnits));
        inputPanel.add(createInputRow("Hotel Cost:", hotelCostField, null));
        inputPanel.add(createInputRow("Food Cost:", foodCostField, null));
        inputPanel.add(createInputRow("Number of Days:", daysField, null));
        inputPanel.add(createInputRow("Attractions Cost:", attractionsCostField, null));

        // Initialize and add the calculate button
        JButton calculateButton = new JButton("Calculate");
        calculateButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        calculateButton.addActionListener(e -> calculateTotalCost());
        inputPanel.add(calculateButton);

        // Initialize the total cost label and add it to the output panel
        totalCostLabel = new JLabel("Total Cost: ");
        JPanel outputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        outputPanel.add(totalCostLabel);

        // Add the input and output panels to the frame
        add(inputPanel, BorderLayout.CENTER);
        add(outputPanel, BorderLayout.SOUTH);

        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private JPanel createInputRow(String label, JTextField textField, JComboBox<String> comboBox) {
        JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        rowPanel.add(new JLabel(label));
        rowPanel.add(textField);
        if (comboBox != null) {
            rowPanel.add(comboBox);
        } else {
            rowPanel.add(Box.createHorizontalStrut(150)); // Placeholder for alignment
        }
        return rowPanel;
    }

    
    private void addComponents(String label, JTextField textField, JComboBox<String> comboBox) {
        add(new JLabel(label));
        add(textField);
        if (comboBox != null) {
            add(comboBox);
        }
    }
    
    private void calculateTotalCost() {
        try {
            double distance = Double.parseDouble(distanceField.getText());
            double gasolineCost = Double.parseDouble(gasolineCostField.getText());
            double gasMileage = Double.parseDouble(gasMileageField.getText());
            double hotelCost = Double.parseDouble(hotelCostField.getText());
            double foodCost = Double.parseDouble(foodCostField.getText());
            int days = Integer.parseInt(daysField.getText());
            double attractionsCost = Double.parseDouble(attractionsCostField.getText());

            // Determine unit flags based on user selection
            boolean isDistanceInMiles = distanceUnits.getSelectedItem().equals("Miles");
            boolean isGasolineCostPerGallon = gasolineCostUnits.getSelectedItem().equals("Dollars per Gallon");
            boolean isGasMileageInMpg = gasMileageUnits.getSelectedItem().equals("Miles per Gallon");

            // Print statements to check input retrieval (optional, for debugging)
            System.out.println("Distance: " + distance);
            System.out.println("Gasoline Cost: " + gasolineCost);
            System.out.println("Gas Mileage: " + gasMileage);
            System.out.println("Hotel Cost: " + hotelCost);
            System.out.println("Food Cost: " + foodCost);
            System.out.println("Days: " + days);
            System.out.println("Attractions Cost: " + attractionsCost);

            // Call the method to calculate and display total cost
            calculateAndDisplayTotalCost(
                distance, gasolineCost, gasMileage, hotelCost, foodCost, days, attractionsCost,
                isDistanceInMiles, isGasolineCostPerGallon, isGasMileageInMpg
            );
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    private void calculateAndDisplayTotalCost(double distance, double gasolineCost, double gasMileage, double hotelCost, double foodCost, int days, double attractionsCost, boolean isDistanceInMiles, boolean isGasolineCostPerGallon, boolean isGasMileageInMpg) {
    	TripCost tripCost = new TripCost(
    		    distance, gasolineCost, gasMileage, hotelCost, foodCost, days, attractionsCost,
    		    isDistanceInMiles, isGasolineCostPerGallon, isGasMileageInMpg
    		);
        double totalCost = tripCost.calculateTotalCost(); // Make sure this method exists in TripCost
        
        totalCostLabel.setText("Total Cost: $" + String.format("%.2f", totalCost));
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Project3::new);
    }
}
